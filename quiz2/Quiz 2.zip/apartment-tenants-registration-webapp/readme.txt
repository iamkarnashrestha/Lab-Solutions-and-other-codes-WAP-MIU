Other than requirements I have implented

-placeholder for the input fields in form.
-prevent the page reloading after it gets submitted.
-clear the textfields after it gets submitted.