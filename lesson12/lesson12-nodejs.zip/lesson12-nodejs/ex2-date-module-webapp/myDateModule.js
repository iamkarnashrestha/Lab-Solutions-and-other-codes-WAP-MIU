/**
 * myDateModule.js
 */
const myDate = function() {
    return new Date();
};

exports.myDate = myDate;
