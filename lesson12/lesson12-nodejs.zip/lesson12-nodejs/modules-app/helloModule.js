/**
 * helloModule.js
 */
const sayHello = function(name) {
    console.log(`Hello, ${name}`);
};
module.exports = sayHello;