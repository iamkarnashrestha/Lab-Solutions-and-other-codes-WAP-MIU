/**
 * app.js
 */
const play = require("./play/musicalInstruments");
play.violin();
play.clarinet();
