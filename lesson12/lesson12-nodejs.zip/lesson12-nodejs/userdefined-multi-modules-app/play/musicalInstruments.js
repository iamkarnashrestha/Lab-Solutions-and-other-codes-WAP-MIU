/**
 * musicalInstruments.js
 */
const violin = require("./violin");
const clarinet = require("./clarinet");

module.exports = { "violin": violin, "clarinet": clarinet };