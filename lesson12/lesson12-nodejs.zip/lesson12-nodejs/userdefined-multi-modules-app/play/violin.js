/**
 * violin.js
 */
const play = function() {
    console.log(`First Violin is playing`);
};
module.exports = play;
