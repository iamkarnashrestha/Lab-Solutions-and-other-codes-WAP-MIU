/**
 * greeting.js
 */
export const greeting = "Hello, ";
//  export { greeting };