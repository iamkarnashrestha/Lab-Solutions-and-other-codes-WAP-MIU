/**
 * dbconfig.js
 */
"use strict";

// Setup the Database config info here
const dbConfig = {
    host: "localhost",
    user: "products-db-sys",
    password: "test1234",
    database: "products-db"
};

module.exports = dbConfig;
